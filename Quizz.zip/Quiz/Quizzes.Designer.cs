﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 08/12/2025
 * Time: 01:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Quiz
{
	partial class Quizzes
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.GroupBox();
			this.lblTextoD = new System.Windows.Forms.Label();
			this.lblTextoC = new System.Windows.Forms.Label();
			this.lblTextoB = new System.Windows.Forms.Label();
			this.lblTextoA = new System.Windows.Forms.Label();
			this.btnAlternativaD = new System.Windows.Forms.Button();
			this.btnAlternativaC = new System.Windows.Forms.Button();
			this.btnAlternativaB = new System.Windows.Forms.Button();
			this.btnAlternativaA = new System.Windows.Forms.Button();
			this.lblPergunta = new System.Windows.Forms.Label();
			this.btnPergunta1 = new System.Windows.Forms.Button();
			this.btnPergunta2 = new System.Windows.Forms.Button();
			this.btnPergunta3 = new System.Windows.Forms.Button();
			this.btnPergunta4 = new System.Windows.Forms.Button();
			this.btnPergunta5 = new System.Windows.Forms.Button();
			this.lblPontos = new System.Windows.Forms.Label();
			this.btnResultados = new System.Windows.Forms.Button();
			this.btnReiniciar = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.lblTextoD);
			this.panel1.Controls.Add(this.lblTextoC);
			this.panel1.Controls.Add(this.lblTextoB);
			this.panel1.Controls.Add(this.lblTextoA);
			this.panel1.Controls.Add(this.btnAlternativaD);
			this.panel1.Controls.Add(this.btnAlternativaC);
			this.panel1.Controls.Add(this.btnAlternativaB);
			this.panel1.Controls.Add(this.btnAlternativaA);
			this.panel1.Controls.Add(this.lblPergunta);
			this.panel1.Location = new System.Drawing.Point(12, 54);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(708, 304);
			this.panel1.TabIndex = 0;
			this.panel1.TabStop = false;
			this.panel1.Text = "groupBox1";
			// 
			// lblTextoD
			// 
			this.lblTextoD.BackColor = System.Drawing.Color.Navy;
			this.lblTextoD.ForeColor = System.Drawing.Color.White;
			this.lblTextoD.Location = new System.Drawing.Point(105, 256);
			this.lblTextoD.Name = "lblTextoD";
			this.lblTextoD.Size = new System.Drawing.Size(555, 33);
			this.lblTextoD.TabIndex = 8;
			this.lblTextoD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblTextoC
			// 
			this.lblTextoC.BackColor = System.Drawing.Color.Navy;
			this.lblTextoC.ForeColor = System.Drawing.Color.White;
			this.lblTextoC.Location = new System.Drawing.Point(105, 202);
			this.lblTextoC.Name = "lblTextoC";
			this.lblTextoC.Size = new System.Drawing.Size(555, 33);
			this.lblTextoC.TabIndex = 7;
			this.lblTextoC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblTextoC.Click += new System.EventHandler(this.LblTextoCClick);
			// 
			// lblTextoB
			// 
			this.lblTextoB.BackColor = System.Drawing.Color.Navy;
			this.lblTextoB.ForeColor = System.Drawing.Color.White;
			this.lblTextoB.Location = new System.Drawing.Point(105, 147);
			this.lblTextoB.Name = "lblTextoB";
			this.lblTextoB.Size = new System.Drawing.Size(555, 33);
			this.lblTextoB.TabIndex = 6;
			this.lblTextoB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblTextoA
			// 
			this.lblTextoA.BackColor = System.Drawing.Color.Navy;
			this.lblTextoA.ForeColor = System.Drawing.Color.White;
			this.lblTextoA.Location = new System.Drawing.Point(105, 96);
			this.lblTextoA.Name = "lblTextoA";
			this.lblTextoA.Size = new System.Drawing.Size(555, 33);
			this.lblTextoA.TabIndex = 5;
			this.lblTextoA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnAlternativaD
			// 
			this.btnAlternativaD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnAlternativaD.Location = new System.Drawing.Point(7, 255);
			this.btnAlternativaD.Name = "btnAlternativaD";
			this.btnAlternativaD.Size = new System.Drawing.Size(76, 34);
			this.btnAlternativaD.TabIndex = 4;
			this.btnAlternativaD.Text = "D";
			this.btnAlternativaD.UseVisualStyleBackColor = false;
			// 
			// btnAlternativaC
			// 
			this.btnAlternativaC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnAlternativaC.Location = new System.Drawing.Point(7, 201);
			this.btnAlternativaC.Name = "btnAlternativaC";
			this.btnAlternativaC.Size = new System.Drawing.Size(76, 34);
			this.btnAlternativaC.TabIndex = 3;
			this.btnAlternativaC.Text = "C";
			this.btnAlternativaC.UseVisualStyleBackColor = false;
			// 
			// btnAlternativaB
			// 
			this.btnAlternativaB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnAlternativaB.Location = new System.Drawing.Point(7, 147);
			this.btnAlternativaB.Name = "btnAlternativaB";
			this.btnAlternativaB.Size = new System.Drawing.Size(76, 34);
			this.btnAlternativaB.TabIndex = 2;
			this.btnAlternativaB.Text = "B";
			this.btnAlternativaB.UseVisualStyleBackColor = false;
			// 
			// btnAlternativaA
			// 
			this.btnAlternativaA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnAlternativaA.ForeColor = System.Drawing.Color.Black;
			this.btnAlternativaA.Location = new System.Drawing.Point(7, 95);
			this.btnAlternativaA.Name = "btnAlternativaA";
			this.btnAlternativaA.Size = new System.Drawing.Size(76, 34);
			this.btnAlternativaA.TabIndex = 1;
			this.btnAlternativaA.Text = "A";
			this.btnAlternativaA.UseVisualStyleBackColor = false;
			// 
			// lblPergunta
			// 
			this.lblPergunta.BackColor = System.Drawing.Color.Navy;
			this.lblPergunta.ForeColor = System.Drawing.Color.White;
			this.lblPergunta.Location = new System.Drawing.Point(6, 36);
			this.lblPergunta.Name = "lblPergunta";
			this.lblPergunta.Size = new System.Drawing.Size(696, 57);
			this.lblPergunta.TabIndex = 0;
			this.lblPergunta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnPergunta1
			// 
			this.btnPergunta1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnPergunta1.Location = new System.Drawing.Point(10, 400);
			this.btnPergunta1.Name = "btnPergunta1";
			this.btnPergunta1.Size = new System.Drawing.Size(41, 34);
			this.btnPergunta1.TabIndex = 1;
			this.btnPergunta1.Text = "1";
			this.btnPergunta1.UseVisualStyleBackColor = false;
			// 
			// btnPergunta2
			// 
			this.btnPergunta2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnPergunta2.Location = new System.Drawing.Point(57, 400);
			this.btnPergunta2.Name = "btnPergunta2";
			this.btnPergunta2.Size = new System.Drawing.Size(41, 34);
			this.btnPergunta2.TabIndex = 2;
			this.btnPergunta2.Text = "2";
			this.btnPergunta2.UseVisualStyleBackColor = false;
			// 
			// btnPergunta3
			// 
			this.btnPergunta3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnPergunta3.Location = new System.Drawing.Point(104, 400);
			this.btnPergunta3.Name = "btnPergunta3";
			this.btnPergunta3.Size = new System.Drawing.Size(41, 34);
			this.btnPergunta3.TabIndex = 3;
			this.btnPergunta3.Text = "3";
			this.btnPergunta3.UseVisualStyleBackColor = false;
			// 
			// btnPergunta4
			// 
			this.btnPergunta4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnPergunta4.Location = new System.Drawing.Point(151, 400);
			this.btnPergunta4.Name = "btnPergunta4";
			this.btnPergunta4.Size = new System.Drawing.Size(41, 34);
			this.btnPergunta4.TabIndex = 4;
			this.btnPergunta4.Text = "4";
			this.btnPergunta4.UseVisualStyleBackColor = false;
			// 
			// btnPergunta5
			// 
			this.btnPergunta5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnPergunta5.Location = new System.Drawing.Point(198, 400);
			this.btnPergunta5.Name = "btnPergunta5";
			this.btnPergunta5.Size = new System.Drawing.Size(41, 34);
			this.btnPergunta5.TabIndex = 5;
			this.btnPergunta5.Text = "5";
			this.btnPergunta5.UseVisualStyleBackColor = false;
			// 
			// lblPontos
			// 
			this.lblPontos.BackColor = System.Drawing.Color.Navy;
			this.lblPontos.ForeColor = System.Drawing.Color.White;
			this.lblPontos.Location = new System.Drawing.Point(555, 407);
			this.lblPontos.Name = "lblPontos";
			this.lblPontos.Size = new System.Drawing.Size(39, 33);
			this.lblPontos.TabIndex = 9;
			this.lblPontos.Text = "000";
			// 
			// btnResultados
			// 
			this.btnResultados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnResultados.Location = new System.Drawing.Point(333, 400);
			this.btnResultados.Name = "btnResultados";
			this.btnResultados.Size = new System.Drawing.Size(131, 34);
			this.btnResultados.TabIndex = 10;
			this.btnResultados.Text = "RESULTADOS";
			this.btnResultados.UseVisualStyleBackColor = false;
			// 
			// btnReiniciar
			// 
			this.btnReiniciar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnReiniciar.Location = new System.Drawing.Point(600, 400);
			this.btnReiniciar.Name = "btnReiniciar";
			this.btnReiniciar.Size = new System.Drawing.Size(112, 34);
			this.btnReiniciar.TabIndex = 11;
			this.btnReiniciar.Text = "REINICIAR";
			this.btnReiniciar.UseVisualStyleBackColor = false;
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Navy;
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(470, 407);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(79, 33);
			this.label6.TabIndex = 12;
			this.label6.Text = "PONTOS:";
			// 
			// Quizzes
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(732, 468);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.btnReiniciar);
			this.Controls.Add(this.btnResultados);
			this.Controls.Add(this.lblPontos);
			this.Controls.Add(this.btnPergunta5);
			this.Controls.Add(this.btnPergunta4);
			this.Controls.Add(this.btnPergunta3);
			this.Controls.Add(this.btnPergunta2);
			this.Controls.Add(this.btnPergunta1);
			this.Controls.Add(this.panel1);
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "Quizzes";
			this.Text = "Quizzes";
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button btnReiniciar;
		private System.Windows.Forms.Button btnResultados;
		private System.Windows.Forms.Label lblPontos;
		private System.Windows.Forms.Button btnPergunta5;
		private System.Windows.Forms.Button btnPergunta4;
		private System.Windows.Forms.Button btnPergunta3;
		private System.Windows.Forms.Button btnPergunta2;
		private System.Windows.Forms.Button btnPergunta1;
		private System.Windows.Forms.Label lblTextoA;
		private System.Windows.Forms.Label lblTextoB;
		private System.Windows.Forms.Label lblTextoC;
		private System.Windows.Forms.Label lblTextoD;
		private System.Windows.Forms.Label lblPergunta;
		private System.Windows.Forms.Button btnAlternativaA;
		private System.Windows.Forms.Button btnAlternativaB;
		private System.Windows.Forms.Button btnAlternativaC;
		private System.Windows.Forms.Button btnAlternativaD;
		private System.Windows.Forms.GroupBox panel1;
	}
}
