﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 07/12/2025
 * Time: 21:31
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Quiz
{
    public partial class Login : Form
    {
        string arquivo = "usuarios.txt";

        public Login()
        {
            InitializeComponent();
        }
        
        private void BtnCadastrarClick(object sender, EventArgs e)
		{
		    Cadastro telaCadastro = new Cadastro();
		    telaCadastro.Show();
		    this.Hide();
		}

        // Botão LOGIN
        private void BtnLoginClick(object sender, EventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string email = txtEmail.Text.Trim();

            if (nome == "" || email == "")
            {
                MessageBox.Show("Preencha o nome e o email.");
                return;
            }

            if (!File.Exists(arquivo))
            {
                MessageBox.Show("Nenhum usuário cadastrado.");
                return;
            }

            bool encontrado = false;

            foreach (string linha in File.ReadAllLines(arquivo))
            {
                string[] dados = linha.Split(';');

                // dados[0] = nome
                // dados[1] = email
                // dados[2] = cpf
                // dados[3] = telefone

                if (dados[0] == nome && dados[1] == email)
                {
                    MessageBox.Show("Login realizado com sucesso!");
                    encontrado = true;

                    MainForm telaPrincipal = new MainForm();
                    telaPrincipal.Show();
                    this.Hide();
                    return;
                }
            }

            if (!encontrado)
            {
                MessageBox.Show("Nome ou email incorretos.");
                txtNome.Clear();
                txtEmail.Clear();
            }
        }
    }
}

