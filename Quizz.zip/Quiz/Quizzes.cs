﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 08/12/2025
 * Time: 01:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Quiz
{
	/// <summary>
	/// Description of Quizzes.
	/// </summary>
	public partial class Quizzes : Form
	{
		public Quizzes()
		{
			InitializeComponent();
		}string AlternativaCorreta = "x";
int pontos = 0;
void BtnAlternativaAClick(object sender, EventArgs e)
        {
if (AlternativaCorreta == "A"){
                MessageBox.Show("Parabéns! Você acertou.");
                pontos++;
                lblPontos.Text = "Pontos: " +pontos;
            } else {     
                MessageBox.Show("Você errou.");
            }
            panel1.Enabled = false;
        }
void BtnAlternativaBClick(object sender, EventArgs e)
        {
if (AlternativaCorreta == "B"){
                MessageBox.Show("Parabéns! Você acertou.");
                pontos++;
                lblPontos.Text = "Pontos: " +pontos;
            } else {     
                MessageBox.Show("Você errou.");
            }
            panel1.Enabled = false;
        }
void BtnAlternativaCClick(object sender, EventArgs e)
        {
if (AlternativaCorreta == "C"){
                MessageBox.Show("Parabéns! Você acertou.");
                pontos++;
                lblPontos.Text = "Pontos: " +pontos;
            } else {     
                MessageBox.Show("Você errou.");
            }
            panel1.Enabled = false;
        }
void BtnAlternativaDClick(object sender, EventArgs e)
        {
if (AlternativaCorreta == "D"){
                MessageBox.Show("Parabéns! Você acertou.");
                pontos++;
                lblPontos.Text = "Pontos: " +pontos;
            } else {     
                MessageBox.Show("Você errou.");
            }
            panel1.Enabled = false;
        }
void BtnPergunta1Click(object sender, EventArgs e)
        {
    lblPergunta.Text = "Qual foi o principal motivo que levou Portugal a iniciar as Grandes Navegações no século XV?";
    lblTextoA.Text = "A necessidade de conquistar novos territórios na Ásia Central.";
    lblTextoB.Text = "A busca por novas rotas comerciais para obter especiarias e metais preciosos.";
    lblTextoC.Text = "O interesse em expandir o Império Romano.";
    lblTextoD.Text = "A tentativa de fugir de conflitos internos causados pela Revolução Francesa.";
    AlternativaCorreta = "B";
        panel1.Enabled = true;
        btnPergunta1.Enabled = false;
        btnPergunta2.Enabled = true;
        }
void BtnPergunta2Click(object sender, EventArgs e)
        {
    lblPergunta.Text = "Qual evento marcou o início da Idade Contemporânea?";
    lblTextoA.Text = "A queda do Império Romano do Ocidente (476).";
    lblTextoB.Text = "A chegada dos europeus à América (1492).";
    lblTextoC.Text = "A Revolução Francesa (1789).";
    lblTextoD.Text = "A Primeira Guerra Mundial (1914).";
    AlternativaCorreta = "C";
        panel1.Enabled = true;
        btnPergunta2.Enabled = false;
        btnPergunta3.Enabled = true;    
        }
void BtnPergunta3Click(object sender, EventArgs e)
        {
    lblPergunta.Text = "Qual foi a principal consequência da assinatura do Tratado de Tordesilhas (1494)?";
    lblTextoA.Text = "A divisão das terras da América entre França e Inglaterra.";
    lblTextoB.Text = "A divisão das áreas de exploração marítima entre Portugal e Espanha.";
    lblTextoC.Text = "O fim das disputas territoriais entre Portugal e Itália.";
    lblTextoD.Text = "A criação das primeiras colônias portuguesas na África.";
    AlternativaCorreta = "B";
        panel1.Enabled = true;
        btnPergunta3.Enabled = false;
        btnPergunta4.Enabled = true;            
        }
void BtnPergunta4Click(object sender, EventArgs e)
        {
    lblPergunta.Text = "A Revolução Industrial teve início em qual país?";
    lblTextoA.Text = "França";
    lblTextoB.Text = "Alemanha";
    lblTextoC.Text = "Inglaterra";
    lblTextoD.Text = "Estados Unidos";
    AlternativaCorreta = "C";
        panel1.Enabled = true;
        btnPergunta4.Enabled = false;
        btnPergunta5.Enabled = true;            
        }
void BtnPergunta5Click(object sender, EventArgs e)
        {
    lblPergunta.Text = "Qual era o objetivo central do movimento iluminista no século XVIII?";
    lblTextoA.Text = "Defender a autoridade absoluta dos reis.";
    lblTextoB.Text = "Promover a razão, a ciência e a liberdade como bases da sociedade.";
    lblTextoC.Text = "Expandir o poder da Igreja Católica.";
    lblTextoD.Text = "Reviver valores feudais da Idade Média.";
    AlternativaCorreta = "B";
        panel1.Enabled = true;
        btnPergunta5.Enabled = false;
        btnResultados.Enabled = true;
        }
void BtnReiniciarClick(object sender, EventArgs e)
        {
            Application.Restart();
        }
void LblPontosClick(object sender, EventArgs e)
        {
        }
void BtnResultadosClick(object sender, EventArgs e)
        {
if(pontos == 5) {
                MessageBox.Show("Parabéns! Você acertou todas ^~^");
            }else {
                MessageBox.Show("Que pena, você não acertou todas. Tente Novamente");
            }
		}
	}
}