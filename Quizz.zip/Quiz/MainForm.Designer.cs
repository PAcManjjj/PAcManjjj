﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 07/12/2025
 * Time: 19:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Quiz
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnQuiz = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.btnNotifica = new System.Windows.Forms.Button();
			this.btnPlacar = new System.Windows.Forms.Button();
			this.btnPlano = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.panel13 = new System.Windows.Forms.Panel();
			this.panel14 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel11.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(250)))), ((int)(((byte)(199)))));
			this.panel1.Controls.Add(this.btnQuiz);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.btnNotifica);
			this.panel1.Controls.Add(this.btnPlacar);
			this.panel1.Controls.Add(this.btnPlano);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Location = new System.Drawing.Point(-2, 0);
			this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(861, 71);
			this.panel1.TabIndex = 0;
			// 
			// btnQuiz
			// 
			this.btnQuiz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnQuiz.Image = ((System.Drawing.Image)(resources.GetObject("btnQuiz.Image")));
			this.btnQuiz.Location = new System.Drawing.Point(408, 8);
			this.btnQuiz.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnQuiz.Name = "btnQuiz";
			this.btnQuiz.Size = new System.Drawing.Size(46, 57);
			this.btnQuiz.TabIndex = 5;
			this.btnQuiz.UseVisualStyleBackColor = true;
			// 
			// panel3
			// 
			this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
			this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel3.Location = new System.Drawing.Point(506, 8);
			this.panel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(338, 57);
			this.panel3.TabIndex = 1;
			// 
			// btnNotifica
			// 
			this.btnNotifica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnNotifica.Image = ((System.Drawing.Image)(resources.GetObject("btnNotifica.Image")));
			this.btnNotifica.Location = new System.Drawing.Point(328, 8);
			this.btnNotifica.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnNotifica.Name = "btnNotifica";
			this.btnNotifica.Size = new System.Drawing.Size(46, 57);
			this.btnNotifica.TabIndex = 4;
			this.btnNotifica.UseVisualStyleBackColor = true;
			this.btnNotifica.Click += new System.EventHandler(this.BtnNotificaClick);
			// 
			// btnPlacar
			// 
			this.btnPlacar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPlacar.Image = ((System.Drawing.Image)(resources.GetObject("btnPlacar.Image")));
			this.btnPlacar.Location = new System.Drawing.Point(232, 5);
			this.btnPlacar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPlacar.Name = "btnPlacar";
			this.btnPlacar.Size = new System.Drawing.Size(69, 62);
			this.btnPlacar.TabIndex = 3;
			this.btnPlacar.UseVisualStyleBackColor = true;
			// 
			// btnPlano
			// 
			this.btnPlano.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPlano.Image = ((System.Drawing.Image)(resources.GetObject("btnPlano.Image")));
			this.btnPlano.Location = new System.Drawing.Point(135, 9);
			this.btnPlano.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPlano.Name = "btnPlano";
			this.btnPlano.Size = new System.Drawing.Size(68, 52);
			this.btnPlano.TabIndex = 2;
			this.btnPlano.UseVisualStyleBackColor = true;
			this.btnPlano.Click += new System.EventHandler(this.BtnPlanoClick);
			// 
			// panel2
			// 
			this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
			this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel2.Location = new System.Drawing.Point(20, 8);
			this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(99, 58);
			this.panel2.TabIndex = 1;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.Transparent;
			this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
			this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel4.Location = new System.Drawing.Point(18, 100);
			this.panel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(441, 154);
			this.panel4.TabIndex = 1;
			// 
			// panel5
			// 
			this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
			this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel5.Location = new System.Drawing.Point(506, 100);
			this.panel5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(341, 154);
			this.panel5.TabIndex = 2;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(19)))), ((int)(((byte)(188)))));
			this.panel6.Location = new System.Drawing.Point(40, 302);
			this.panel6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(216, 251);
			this.panel6.TabIndex = 3;
			// 
			// panel7
			// 
			this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
			this.panel7.Controls.Add(this.panel12);
			this.panel7.Location = new System.Drawing.Point(18, 312);
			this.panel7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(220, 212);
			this.panel7.TabIndex = 0;
			// 
			// panel12
			// 
			this.panel12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel12.BackgroundImage")));
			this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel12.Location = new System.Drawing.Point(27, 63);
			this.panel12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(156, 85);
			this.panel12.TabIndex = 0;
			// 
			// panel8
			// 
			this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
			this.panel8.Controls.Add(this.panel9);
			this.panel8.Location = new System.Drawing.Point(318, 312);
			this.panel8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(220, 212);
			this.panel8.TabIndex = 4;
			// 
			// panel9
			// 
			this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
			this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel9.Location = new System.Drawing.Point(27, 63);
			this.panel9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(156, 85);
			this.panel9.TabIndex = 0;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(19)))), ((int)(((byte)(188)))));
			this.panel10.Location = new System.Drawing.Point(340, 302);
			this.panel10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(216, 251);
			this.panel10.TabIndex = 5;
			// 
			// panel11
			// 
			this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
			this.panel11.Controls.Add(this.panel13);
			this.panel11.Location = new System.Drawing.Point(603, 312);
			this.panel11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(220, 212);
			this.panel11.TabIndex = 6;
			// 
			// panel13
			// 
			this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
			this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel13.Location = new System.Drawing.Point(27, 63);
			this.panel13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(156, 85);
			this.panel13.TabIndex = 0;
			// 
			// panel14
			// 
			this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(19)))), ((int)(((byte)(188)))));
			this.panel14.Location = new System.Drawing.Point(626, 302);
			this.panel14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel14.Name = "panel14";
			this.panel14.Size = new System.Drawing.Size(216, 251);
			this.panel14.TabIndex = 7;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.ClientSize = new System.Drawing.Size(860, 492);
			this.Controls.Add(this.panel11);
			this.Controls.Add(this.panel14);
			this.Controls.Add(this.panel8);
			this.Controls.Add(this.panel10);
			this.Controls.Add(this.panel7);
			this.Controls.Add(this.panel6);
			this.Controls.Add(this.panel5);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel1);
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "MainForm";
			this.Text = "Quiz";
			this.panel1.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel11.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnQuiz;
		private System.Windows.Forms.Panel panel14;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Button btnPlacar;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnPlano;
		private System.Windows.Forms.Button btnNotifica;
		private System.Windows.Forms.Panel panel1;
	}
}
