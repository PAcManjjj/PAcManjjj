﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 08/12/2025
 * Time: 01:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Quiz
{
	partial class Placar
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.lblTitulo = new System.Windows.Forms.Label();
			this.btnVoltar3 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGridView1
			// 
			this.dataGridView1.AllowUserToAddRows = false;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(154, 21);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.ReadOnly = true;
			this.dataGridView1.RowHeadersVisible = false;
			this.dataGridView1.RowTemplate.Height = 28;
			this.dataGridView1.Size = new System.Drawing.Size(405, 435);
			this.dataGridView1.TabIndex = 0;
			// 
			// lblTitulo
			// 
			this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.Location = new System.Drawing.Point(322, 80);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Size = new System.Drawing.Size(103, 32);
			this.lblTitulo.TabIndex = 1;
			this.lblTitulo.Text = "Placar";
			this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnVoltar3
			// 
			this.btnVoltar3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(19)))), ((int)(((byte)(188)))));
			this.btnVoltar3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnVoltar3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar3.ForeColor = System.Drawing.Color.White;
			this.btnVoltar3.Location = new System.Drawing.Point(206, 80);
			this.btnVoltar3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnVoltar3.Name = "btnVoltar3";
			this.btnVoltar3.Size = new System.Drawing.Size(83, 35);
			this.btnVoltar3.TabIndex = 2;
			this.btnVoltar3.Text = "Voltar";
			this.btnVoltar3.UseVisualStyleBackColor = false;
			this.btnVoltar3.Click += new System.EventHandler(this.BtnVoltar3Click);
			// 
			// Placar
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(645, 489);
			this.Controls.Add(this.btnVoltar3);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.dataGridView1);
			this.Name = "Placar";
			this.Text = "Placar";
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnVoltar3;
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.DataGridView dataGridView1;
	}
}
