﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 08/12/2025
 * Time: 01:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Quiz
{
	/// <summary>
	/// Description of Quizzes.
	/// </summary>
	public partial class Quizzes : Form
	{
		public Quizzes()
		{
			InitializeComponent();
		}
	}
}
