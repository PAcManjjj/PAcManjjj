﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 08/12/2025
 * Time: 00:08
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Quiz
{
	partial class Planos
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Planos));
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnVoltar1 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Black;
			this.panel1.Controls.Add(this.btnVoltar1);
			this.panel1.Location = new System.Drawing.Point(495, 12);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(82, 30);
			this.panel1.TabIndex = 0;
			// 
			// btnVoltar1
			// 
			this.btnVoltar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(19)))), ((int)(((byte)(188)))));
			this.btnVoltar1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnVoltar1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar1.ForeColor = System.Drawing.Color.White;
			this.btnVoltar1.Location = new System.Drawing.Point(3, 3);
			this.btnVoltar1.Name = "btnVoltar1";
			this.btnVoltar1.Size = new System.Drawing.Size(75, 23);
			this.btnVoltar1.TabIndex = 0;
			this.btnVoltar1.Text = "Voltar";
			this.btnVoltar1.UseVisualStyleBackColor = false;
			this.btnVoltar1.Click += new System.EventHandler(this.BtnVoltar1Click);
			// 
			// Planos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(644, 278);
			this.Controls.Add(this.panel1);
			this.Name = "Planos";
			this.Text = "Planos";
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnVoltar1;
		private System.Windows.Forms.Panel panel1;
	}
}
