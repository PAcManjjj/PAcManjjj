﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 08/12/2025
 * Time: 01:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Quiz
{
	/// <summary>
	/// Description of Placar.
	/// </summary>
	public partial class Placar : Form
	{
		public Placar()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
