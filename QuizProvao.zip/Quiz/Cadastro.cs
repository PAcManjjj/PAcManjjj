﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 07/12/2025
 * Time: 21:09
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Quiz
{
    public partial class Cadastro : Form
    {
        string arquivo = "usuarios.txt";

        public Cadastro()
        {
            InitializeComponent();
        }

        // Botão CADASTRAR
        private void BtnCadastrarClick(object sender, EventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string email = txtEmail.Text.Trim();
            string cpf = txtCpf.Text.Trim();
            string telefone = txtTelefone.Text.Trim();

            if (nome == "" || email == "" || cpf == "" || telefone == "")
            {
                MessageBox.Show("Preencha todos os campos.");
                return;
            }

            bool cadastrado = false;

            // Verifica se o arquivo existe
            if (File.Exists(arquivo))
            {
                foreach (string linha in File.ReadAllLines(arquivo))
                {
                    string[] dados = linha.Split(';');

                    if (dados[0] == nome) // Verifica pelo nome
                    {
                        MessageBox.Show("Nome já cadastrado.");
                        cadastrado = true;
                        return;
                    }
                }
            }

            // Se não estiver cadastrado, grava
            if (!cadastrado)
            {
                using (StreamWriter sw = File.AppendText(arquivo))
                {
                    sw.WriteLine(nome + ";" + email + ";" + cpf + ";" + telefone);
                }

                MessageBox.Show("Cadastro realizado com sucesso!");
            }

            // Limpar campos
            txtNome.Clear();
            txtEmail.Clear();
            txtCpf.Clear();
            txtTelefone.Clear();
        }
		
		void BtnCadastrar2Click(object sender, EventArgs e)
		{
 			MainForm telaPrincipal = new MainForm();
            telaPrincipal.Show();
            this.Hide();			
		}
    }
}
