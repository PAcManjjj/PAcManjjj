﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 07/12/2025
 * Time: 21:09
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Quiz
{
	partial class Cadastro
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cadastro));
			this.panel1 = new System.Windows.Forms.Panel();
			this.txtTelefone = new System.Windows.Forms.TextBox();
			this.txtCpf = new System.Windows.Forms.TextBox();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.txtNome = new System.Windows.Forms.TextBox();
			this.lblTelefone = new System.Windows.Forms.Label();
			this.lblCpf = new System.Windows.Forms.Label();
			this.lblEmail = new System.Windows.Forms.Label();
			this.lblNome = new System.Windows.Forms.Label();
			this.btnCadastrar2 = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
			this.panel1.Controls.Add(this.txtTelefone);
			this.panel1.Controls.Add(this.txtCpf);
			this.panel1.Controls.Add(this.txtEmail);
			this.panel1.Controls.Add(this.txtNome);
			this.panel1.Controls.Add(this.lblTelefone);
			this.panel1.Controls.Add(this.lblCpf);
			this.panel1.Controls.Add(this.lblEmail);
			this.panel1.Controls.Add(this.lblNome);
			this.panel1.Controls.Add(this.btnCadastrar2);
			this.panel1.Location = new System.Drawing.Point(42, 74);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(237, 242);
			this.panel1.TabIndex = 1;
			// 
			// txtTelefone
			// 
			this.txtTelefone.BackColor = System.Drawing.Color.White;
			this.txtTelefone.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtTelefone.Location = new System.Drawing.Point(104, 153);
			this.txtTelefone.Name = "txtTelefone";
			this.txtTelefone.Size = new System.Drawing.Size(114, 13);
			this.txtTelefone.TabIndex = 10;
			// 
			// txtCpf
			// 
			this.txtCpf.BackColor = System.Drawing.Color.White;
			this.txtCpf.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtCpf.Location = new System.Drawing.Point(68, 117);
			this.txtCpf.Name = "txtCpf";
			this.txtCpf.Size = new System.Drawing.Size(150, 13);
			this.txtCpf.TabIndex = 8;
			// 
			// txtEmail
			// 
			this.txtEmail.BackColor = System.Drawing.Color.White;
			this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEmail.Location = new System.Drawing.Point(82, 80);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(136, 13);
			this.txtEmail.TabIndex = 7;
			// 
			// txtNome
			// 
			this.txtNome.BackColor = System.Drawing.Color.White;
			this.txtNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtNome.Location = new System.Drawing.Point(82, 42);
			this.txtNome.Name = "txtNome";
			this.txtNome.Size = new System.Drawing.Size(136, 13);
			this.txtNome.TabIndex = 6;
			// 
			// lblTelefone
			// 
			this.lblTelefone.BackColor = System.Drawing.Color.Transparent;
			this.lblTelefone.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTelefone.ForeColor = System.Drawing.Color.Black;
			this.lblTelefone.Location = new System.Drawing.Point(18, 147);
			this.lblTelefone.Name = "lblTelefone";
			this.lblTelefone.Size = new System.Drawing.Size(80, 23);
			this.lblTelefone.TabIndex = 5;
			this.lblTelefone.Text = "Telefone:";
			// 
			// lblCpf
			// 
			this.lblCpf.BackColor = System.Drawing.Color.Transparent;
			this.lblCpf.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCpf.ForeColor = System.Drawing.Color.Black;
			this.lblCpf.Location = new System.Drawing.Point(18, 111);
			this.lblCpf.Name = "lblCpf";
			this.lblCpf.Size = new System.Drawing.Size(44, 23);
			this.lblCpf.TabIndex = 4;
			this.lblCpf.Text = "CPF:";
			// 
			// lblEmail
			// 
			this.lblEmail.BackColor = System.Drawing.Color.Transparent;
			this.lblEmail.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEmail.ForeColor = System.Drawing.Color.Black;
			this.lblEmail.Location = new System.Drawing.Point(18, 74);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(67, 23);
			this.lblEmail.TabIndex = 3;
			this.lblEmail.Text = "E-mail:";
			// 
			// lblNome
			// 
			this.lblNome.BackColor = System.Drawing.Color.Transparent;
			this.lblNome.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblNome.ForeColor = System.Drawing.Color.Black;
			this.lblNome.Location = new System.Drawing.Point(18, 36);
			this.lblNome.Name = "lblNome";
			this.lblNome.Size = new System.Drawing.Size(67, 23);
			this.lblNome.TabIndex = 2;
			this.lblNome.Text = "Nome:";
			// 
			// btnCadastrar2
			// 
			this.btnCadastrar2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(221)))), ((int)(((byte)(90)))));
			this.btnCadastrar2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCadastrar2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCadastrar2.Location = new System.Drawing.Point(82, 193);
			this.btnCadastrar2.Name = "btnCadastrar2";
			this.btnCadastrar2.Size = new System.Drawing.Size(87, 24);
			this.btnCadastrar2.TabIndex = 0;
			this.btnCadastrar2.Text = "Cadastrar";
			this.btnCadastrar2.UseVisualStyleBackColor = false;
			this.btnCadastrar2.Click += new System.EventHandler(this.BtnCadastrar2Click);
			// 
			// panel2
			// 
			this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
			this.panel2.Location = new System.Drawing.Point(128, 24);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(73, 74);
			this.panel2.TabIndex = 11;
			// 
			// Cadastro
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(320, 357);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Cadastro";
			this.Text = "Cadastro";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label lblCpf;
		private System.Windows.Forms.Label lblTelefone;
		private System.Windows.Forms.TextBox txtCpf;
		private System.Windows.Forms.TextBox txtTelefone;
		private System.Windows.Forms.Button btnCadastrar2;
		private System.Windows.Forms.Label lblNome;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.TextBox txtNome;
		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.Panel panel1;
	}
}
