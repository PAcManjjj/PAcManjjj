﻿/*
 * Created by SharpDevelop.
 * User: Victor
 * Date: 07/12/2025
 * Time: 19:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Quiz
{
    public partial class MainForm : Form
    {

     public MainForm()
{   
     InitializeComponent();
}

		
		void BtnPlanoClick(object sender, EventArgs e)
		{
 			Planos telaPlanos = new Planos();
            telaPlanos.Show();
            this.Hide();			
		}
		
		void BtnNotificaClick(object sender, EventArgs e)
		{
 			Notifica telaNotifica = new Notifica();
            telaNotifica.Show();
            this.Hide();			
		}

		
		void BtnQuizClick(object sender, EventArgs e)
		{
			Quizzes telaQuizzes = new Quizzes();
            telaQuizzes.Show();
            this.Hide();			
		}
		
		void BtnPlacarClick(object sender, EventArgs e)
		{
			Placar telaPlacar = new Placar();
            telaPlacar.Show();
            this.Hide();
		}
    }
}
